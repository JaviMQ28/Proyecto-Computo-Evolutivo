Algoritmo NSGA-II
- Probar el programa alg_nsga2.py con:
    python .\src\alg_nsga2.py .\output\ejemplares\[Nombre del archivo de un ejemplar].txt

    Por ejemplo:
    python .\src\alg_nsga2.py .\output\ejemplares\A-n32-k5.txt